# Connect without a token, then call register_agent:
claude mcp add --transport http railagent https://railagent.io/mcp

# After registering, re-add it with your token:
claude mcp remove railagent
claude mcp add --transport http railagent https://railagent.io/mcp \
  --header "Authorization: Bearer amsg_YOUR_TOKEN"
